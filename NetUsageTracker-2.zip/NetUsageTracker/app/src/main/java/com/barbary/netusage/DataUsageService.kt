package com.barbary.netusage

import android.app.*
import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

/**
 * خدمة تعمل في الخلفية (Foreground Service) تقرأ استهلاك الشبكة
 * كل فترة زمنية ثابتة وتحفظ:
 *  - إجمالي البيانات المستهلكة اليوم (جوال + واي فاي)
 *  - مدة النشاط التقريبية (الوقت الذي كانت فيه الشبكة قيد الاستخدام فعليًا)
 */
class DataUsageService : Service() {

    private lateinit var handlerThread: HandlerThread
    private lateinit var handler: Handler
    private val pollIntervalMs = 60_000L // كل دقيقة

    private var lastMobileBytes = 0L
    private var lastWifiBytes = 0L
    private var lastPollTime = 0L

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    override fun onCreate() {
        super.onCreate()
        handlerThread = HandlerThread("UsagePollThread")
        handlerThread.start()
        handler = Handler(handlerThread.looper)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification())
        handler.post(pollRunnable)
        return START_STICKY
    }

    private val pollRunnable = object : Runnable {
        override fun run() {
            pollUsage()
            handler.postDelayed(this, pollIntervalMs)
        }
    }

    private fun pollUsage() {
        val today = dateFormat.format(Date())
        val (dayStart, now) = todayRangeMillis()

        val mobileBytes = queryBytesForType(ConnectivityManager.TYPE_MOBILE, dayStart, now)
        val wifiBytes = queryBytesForType(ConnectivityManager.TYPE_WIFI, dayStart, now)

        // تقدير مدة النشاط: إذا زاد الاستهلاك منذ آخر فحص، نعتبر أن الشبكة كانت نشطة خلال تلك الفترة
        val currentTotal = mobileBytes + wifiBytes
        val lastTotal = lastMobileBytes + lastWifiBytes
        val nowMs = System.currentTimeMillis()

        var activeDeltaMs = 0L
        if (lastPollTime != 0L && currentTotal > lastTotal) {
            activeDeltaMs = nowMs - lastPollTime
        }

        lastMobileBytes = mobileBytes
        lastWifiBytes = wifiBytes
        lastPollTime = nowMs

        CoroutineScope(Dispatchers.IO).launch {
            val dao = AppDatabase.getInstance(applicationContext).usageDao()
            val existing = dao.getByDate(today)
            val record = existing ?: DailyUsage(date = today)
            record.mobileBytes = mobileBytes
            record.wifiBytes = wifiBytes
            record.activeMillis += activeDeltaMs
            dao.upsert(record)

            checkDataLimit(record.totalBytes)
        }
    }

    /** يقارن الاستهلاك الحالي بالحد الذي حدده المستخدم ويرسل تحذير أو يقطع الاتصال */
    private fun checkDataLimit(totalBytesToday: Long) {
        val limitMb = PrefsHelper.getLimitMb(applicationContext)
        if (limitMb <= 0) return // المستخدم لم يحدد حدًا

        val limitBytes = limitMb * 1024L * 1024L
        val usedMb = totalBytesToday / (1024f * 1024f)
        val percent = (totalBytesToday.toFloat() / limitBytes.toFloat()) * 100f

        // تحذير عند الوصول لـ 90% من الحد (مرة واحدة يوميًا)
        if (percent >= 90f && percent < 100f && !PrefsHelper.hasWarnedToday(applicationContext)) {
            PrefsHelper.markWarnedToday(applicationContext)
            sendWarningNotification(usedMb, limitMb)
        }

        // القطع الفعلي عند تجاوز الحد بالكامل
        if (totalBytesToday >= limitBytes && PrefsHelper.isAutoCutEnabled(applicationContext)
            && !PrefsHelper.hasCutToday(applicationContext)
        ) {
            PrefsHelper.markCutToday(applicationContext)
            triggerCutOff()
        }
    }

    private fun sendWarningNotification(usedMb: Float, limitMb: Long) {
        val channelId = "warning_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "تحذير الاستهلاك", NotificationManager.IMPORTANCE_HIGH
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notif = NotificationCompat.Builder(this, channelId)
            .setContentTitle("⚠️ اقتربت من حد الاستهلاك")
            .setContentText("استهلكت ${usedMb.toInt()} ميجا من أصل $limitMb ميجا المحددة لليوم")
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        getSystemService(NotificationManager::class.java).notify(WARN_NOTIF_ID, notif)
    }

    private fun triggerCutOff() {
        val prepareIntent = android.net.VpnService.prepare(applicationContext)
        if (prepareIntent != null) {
            // المستخدم لم يمنح إذن VPN بعد - لا يمكن القطع فعليًا، نكتفي بإشعار قوي
            val channelId = "warning_channel"
            val notif = NotificationCompat.Builder(this, channelId)
                .setContentTitle("🚫 تجاوزت حد الاستهلاك اليومي")
                .setContentText("افتح التطبيق ووافق على إذن VPN لتفعيل القطع التلقائي")
                .setSmallIcon(android.R.drawable.stat_sys_warning)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .build()
            getSystemService(NotificationManager::class.java).notify(WARN_NOTIF_ID, notif)
            return
        }
        val intent = Intent(this, BlockerVpnService::class.java)
        startService(intent)
    }

    /** يرجع بداية اليوم الحالي (منتصف الليل) والوقت الحالي بالمللي ثانية */
    private fun todayRangeMillis(): Pair<Long, Long> {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return Pair(cal.timeInMillis, System.currentTimeMillis())
    }

    /** يقرأ إجمالي البايتات (رفع+تحميل) لنوع شبكة معين خلال فترة زمنية */
    private fun queryBytesForType(networkType: Int, start: Long, end: Long): Long {
        return try {
            val nsm = getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
            // subscriberId فارغ يعمل لمعظم الأجهزة لقراءة الاستهلاك الكلي لنوع الشبكة
            val bucket = nsm.querySummaryForDevice(networkType, null, start, end)
            bucket.rxBytes + bucket.txBytes
        } catch (e: Exception) {
            0L
        }
    }

    private fun buildNotification(): Notification {
        val channelId = "net_usage_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "مراقبة استهلاك الإنترنت",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("مراقب استهلاك النت يعمل")
            .setContentText("جارٍ تسجيل استهلاك البيانات اليومي")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(pollRunnable)
        handlerThread.quitSafely()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val NOTIF_ID = 1001
        private const val WARN_NOTIF_ID = 1002
    }
}
