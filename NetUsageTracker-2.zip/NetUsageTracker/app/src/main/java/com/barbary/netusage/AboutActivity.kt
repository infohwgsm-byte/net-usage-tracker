package com.barbary.netusage

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.barbary.netusage.databinding.ActivityAboutBinding

/**
 * شاشة "حول التطبيق" تعرض بيانات المطور
 */
class AboutActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAboutBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAboutBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.facebookBtn.setOnClickListener {
            openUrl("https://www.facebook.com/dr.barbary2")
        }

        binding.telegramBtn.setOnClickListener {
            openUrl("https://t.me/apkok2026")
        }
    }

    private fun openUrl(url: String) {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }
}
