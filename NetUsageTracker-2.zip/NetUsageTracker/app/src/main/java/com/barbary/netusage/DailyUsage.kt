package com.barbary.netusage

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * سجل استهلاك يوم واحد
 * date         : التاريخ بصيغة yyyy-MM-dd
 * mobileBytes  : بايتات مستهلكة عبر بيانات الجوال
 * wifiBytes    : بايتات مستهلكة عبر الواي فاي
 * activeMillis : مدة استخدام الشبكة (تقديري) بالمللي ثانية خلال اليوم
 */
@Entity(tableName = "daily_usage")
data class DailyUsage(
    @PrimaryKey val date: String,
    var mobileBytes: Long = 0L,
    var wifiBytes: Long = 0L,
    var activeMillis: Long = 0L
) {
    val totalBytes: Long get() = mobileBytes + wifiBytes
}
