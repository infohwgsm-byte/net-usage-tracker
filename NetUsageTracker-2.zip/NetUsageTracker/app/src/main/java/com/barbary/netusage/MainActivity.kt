package com.barbary.netusage

import android.app.AppOpsManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.barbary.netusage.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: UsageAdapter

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            Toast.makeText(this, "تم تفعيل إذن قطع الاتصال", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "لن يعمل القطع التلقائي بدون هذا الإذن", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = UsageAdapter(emptyList())
        binding.usageRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.usageRecyclerView.adapter = adapter

        binding.grantPermissionBtn.setOnClickListener { openUsageAccessSettings() }

        binding.startServiceBtn.setOnClickListener {
            if (!hasUsageAccess()) {
                openUsageAccessSettings()
                return@setOnClickListener
            }
            requestNotificationPermissionIfNeeded()
            startUsageService()
        }

        binding.aboutBtn.setOnClickListener {
            startActivity(Intent(this, AboutActivity::class.java))
        }

        binding.autoCutCheckbox.setOnCheckedChangeListener { _, checked ->
            PrefsHelper.setAutoCutEnabled(this, checked)
        }

        binding.saveLimitBtn.setOnClickListener { saveLimit() }

        binding.resumeBtn.setOnClickListener { resumeConnection() }

        loadLimitSettings()
    }

    override fun onResume() {
        super.onResume()
        loadUsageData()
        refreshLimitStatus()
    }

    /** يحفظ الحد اليومي الذي أدخله المستخدم ويطلب إذن VPN إذا لزم */
    private fun saveLimit() {
        val text = binding.limitInput.text.toString().trim()
        val mb = text.toLongOrNull()
        if (mb == null || mb <= 0) {
            Toast.makeText(this, "أدخل رقمًا صحيحًا أكبر من صفر", Toast.LENGTH_SHORT).show()
            return
        }
        PrefsHelper.setLimitMb(this, mb)
        PrefsHelper.clearCutState(this)
        Toast.makeText(this, "تم حفظ الحد: $mb ميجا في اليوم", Toast.LENGTH_SHORT).show()
        requestVpnPermissionIfNeeded()
        refreshLimitStatus()
    }

    /** يطلب موافقة النظام لتفعيل خدمة VPN المحلية المستخدمة لقطع الاتصال فعليًا */
    private fun requestVpnPermissionIfNeeded() {
        val intent = VpnService.prepare(this)
        if (intent != null) {
            vpnPermissionLauncher.launch(intent)
        }
    }

    /** يوقف خدمة القطع ويعيد الاتصال بالإنترنت يدويًا */
    private fun resumeConnection() {
        val stopIntent = Intent(this, BlockerVpnService::class.java).apply {
            action = BlockerVpnService.ACTION_STOP
        }
        startService(stopIntent)
        PrefsHelper.clearCutState(this)
        refreshLimitStatus()
        Toast.makeText(this, "تم استئناف الاتصال بالإنترنت", Toast.LENGTH_SHORT).show()
    }

    private fun loadLimitSettings() {
        val limit = PrefsHelper.getLimitMb(this)
        if (limit > 0) binding.limitInput.setText(limit.toString())
        binding.autoCutCheckbox.isChecked = PrefsHelper.isAutoCutEnabled(this)
    }

    private fun refreshLimitStatus() {
        val limit = PrefsHelper.getLimitMb(this)
        val cutActive = PrefsHelper.hasCutToday(this)
        binding.limitStatusText.text = when {
            limit <= 0 -> "لم يتم تحديد حد استهلاك بعد"
            cutActive -> "⚠️ تم قطع الاتصال — تجاوزت حد $limit ميجا اليوم"
            else -> "الحد الحالي: $limit ميجا في اليوم"
        }
        binding.resumeBtn.visibility = if (cutActive) android.view.View.VISIBLE else android.view.View.GONE
    }

    /** يتحقق إذا كان إذن "الوصول لإحصائيات الاستخدام" ممنوح (ضروري لقراءة NetworkStatsManager) */
    private fun hasUsageAccess(): Boolean {
        val appOps = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            android.os.Process.myUid(),
            packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun openUsageAccessSettings() {
        startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this, android.Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),
                    100
                )
            }
        }
    }

    private fun startUsageService() {
        val intent = Intent(this, DataUsageService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun loadUsageData() {
        CoroutineScope(Dispatchers.IO).launch {
            val dao = AppDatabase.getInstance(applicationContext).usageDao()
            val list = dao.getAll()
            withContext(Dispatchers.Main) {
                adapter.updateData(list)
            }
        }
    }
}
