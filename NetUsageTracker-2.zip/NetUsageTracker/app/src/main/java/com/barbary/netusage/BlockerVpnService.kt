package com.barbary.netusage

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import kotlin.concurrent.thread

/**
 * خدمة VPN محلية لا تُرسل أي بيانات لأي مكان (Blackhole) — تُستخدم لقطع الاتصال
 * بالإنترنت فعليًا عن الجهاز عندما يتجاوز المستخدم الحد اليومي المحدد.
 * هذه هي نفس الطريقة المستخدمة في تطبيقات الجدار الناري بدون روت (مثل NetGuard).
 * تتطلب موافقة المستخدم مرة واحدة عبر نافذة نظام أندرويد القياسية لتفعيل VPN.
 */
class BlockerVpnService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null
    private var running = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopBlocking()
            return START_NOT_STICKY
        }
        startForeground(NOTIF_ID, buildNotification())
        startBlocking()
        return START_STICKY
    }

    private fun startBlocking() {
        if (running) return
        try {
            val builder = Builder()
                .setSession("قطع النت - تجاوز الحد")
                .addAddress("10.0.0.2", 32)
                .addRoute("0.0.0.0", 0) // توجيه كل حركة المرور عبر هذا الـ VPN الوهمي
                .setBlocking(true)

            vpnInterface = builder.establish()
            running = true

            // نقرأ أي حزم واردة ونتجاهلها فورًا (لا تخرج لأي مكان) = قطع فعلي للاتصال
            thread(start = true) {
                val fd = vpnInterface ?: return@thread
                val input = ParcelFileDescriptor.AutoCloseInputStream(fd)
                val buffer = ByteArray(32767)
                try {
                    while (running) {
                        input.read(buffer)
                    }
                } catch (e: Exception) {
                    // الخدمة أُوقفت
                }
            }
        } catch (e: Exception) {
            running = false
        }
    }

    private fun stopBlocking() {
        running = false
        try {
            vpnInterface?.close()
        } catch (e: Exception) { }
        vpnInterface = null
        stopForeground(true)
        stopSelf()
    }

    private fun buildNotification(): Notification {
        val channelId = "block_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "قطع الاتصال", NotificationManager.IMPORTANCE_HIGH
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("تم قطع الإنترنت")
            .setContentText("تجاوزت حد الاستهلاك اليومي الذي حددته. اضغط لإدارة الإعدادات.")
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
    }

    override fun onDestroy() {
        stopBlocking()
        super.onDestroy()
    }

    companion object {
        private const val NOTIF_ID = 2002
        const val ACTION_STOP = "com.barbary.netusage.STOP_BLOCK"

        fun isBlockingActive(context: android.content.Context): Boolean {
            return PrefsHelper.hasCutToday(context)
        }
    }
}
