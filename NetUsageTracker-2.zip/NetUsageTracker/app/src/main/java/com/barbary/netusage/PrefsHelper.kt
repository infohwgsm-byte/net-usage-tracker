package com.barbary.netusage

import android.content.Context
import java.text.SimpleDateFormat
import java.util.*

/**
 * تخزين إعدادات حد الاستهلاك اليومي وحالة التحذير/القطع لهذا اليوم
 */
object PrefsHelper {
    private const val PREFS = "monitor_prefs"
    private const val KEY_LIMIT_MB = "limit_mb"           // 0 = بدون حد
    private const val KEY_AUTO_CUT = "auto_cut_enabled"   // تفعيل القطع التلقائي
    private const val KEY_WARN_DATE = "warned_date"       // آخر يوم تم إرسال تحذير فيه
    private const val KEY_CUT_DATE = "cut_date"           // آخر يوم تم القطع فيه

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun today(): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    fun setLimitMb(context: Context, limitMb: Long) {
        prefs(context).edit().putLong(KEY_LIMIT_MB, limitMb).apply()
    }

    /** 0 تعني أن المستخدم لم يحدد حدًا بعد */
    fun getLimitMb(context: Context): Long =
        prefs(context).getLong(KEY_LIMIT_MB, 0L)

    fun setAutoCutEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_AUTO_CUT, enabled).apply()
    }

    fun isAutoCutEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_AUTO_CUT, true)

    fun hasWarnedToday(context: Context): Boolean =
        prefs(context).getString(KEY_WARN_DATE, "") == today()

    fun markWarnedToday(context: Context) {
        prefs(context).edit().putString(KEY_WARN_DATE, today()).apply()
    }

    fun hasCutToday(context: Context): Boolean =
        prefs(context).getString(KEY_CUT_DATE, "") == today()

    fun markCutToday(context: Context) {
        prefs(context).edit().putString(KEY_CUT_DATE, today()).apply()
    }

    /** يُستدعى عند بداية يوم جديد أو عند رفع/تعطيل الحد يدويًا لإلغاء حالة القطع المسجّلة */
    fun clearCutState(context: Context) {
        prefs(context).edit().remove(KEY_CUT_DATE).apply()
    }
}
