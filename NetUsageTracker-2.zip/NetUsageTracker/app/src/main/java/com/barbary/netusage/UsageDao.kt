package com.barbary.netusage

import androidx.room.*

@Dao
interface UsageDao {

    @Query("SELECT * FROM daily_usage ORDER BY date DESC")
    suspend fun getAll(): List<DailyUsage>

    @Query("SELECT * FROM daily_usage WHERE date = :date LIMIT 1")
    suspend fun getByDate(date: String): DailyUsage?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(usage: DailyUsage)
}
