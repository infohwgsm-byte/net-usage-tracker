package com.barbary.netusage

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.TimeUnit

class UsageAdapter(private var items: List<DailyUsage>) :
    RecyclerView.Adapter<UsageAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val dateText: TextView = view.findViewById(R.id.dateText)
        val totalText: TextView = view.findViewById(R.id.totalText)
        val durationText: TextView = view.findViewById(R.id.durationText)
    }

    fun updateData(newItems: List<DailyUsage>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_usage, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.dateText.text = item.date
        holder.totalText.text = "الإجمالي: ${formatBytes(item.totalBytes)} " +
                "(جوال: ${formatBytes(item.mobileBytes)} | واي فاي: ${formatBytes(item.wifiBytes)})"
        holder.durationText.text = "مدة الاستخدام التقريبية: ${formatDuration(item.activeMillis)}"
    }

    override fun getItemCount(): Int = items.size

    private fun formatBytes(bytes: Long): String {
        val mb = bytes / (1024.0 * 1024.0)
        return if (mb >= 1024) String.format("%.2f جيجا", mb / 1024) else String.format("%.1f ميجا", mb)
    }

    private fun formatDuration(millis: Long): String {
        val hours = TimeUnit.MILLISECONDS.toHours(millis)
        val minutes = TimeUnit.MILLISECONDS.toMinutes(millis) % 60
        return "${hours} س ${minutes} د"
    }
}
